#include "sudoku.h"
#include <iostream>
#include <random>
#include <ctime>

using namespace std;

/*
@ name: Sudoku
@ brief: calls grid and randomly generates a sudoku board
@ param: int n
@ retval: none
*/

Sudoku::Sudoku(int n) {
    //declares grid as a vector
    grid.resize(9, vector<int>(9, 0));

    //randomly part of puzzle generation
    srand(time(0));

    generatePuzzle(n);
}

/*
@ name: generatePuzzle
@ brief: generates sudoku puzzle
@ param: int n
@ retval: none
*/

void Sudoku::generatePuzzle(int n) {
    int count = 0;
    while (count < n) {
        //randomly selects squares to put values in
        int row = rand() % 9;
        int col = rand() % 9;
        int num = rand() % 9 + 1;

        //makes sure place selected is valid
        if (grid[row][col] == 0 && isSafe(row, col, num)) {
            grid[row][col] = num;
            count++;
        }
    }
}

/*
@ name: isSafe
@ brief: makes sure square selected is valid
@ param: row, col, num
@ retval: false or true
*/

bool Sudoku::isSafe(int row, int col, int num) {
    //checks to make sure row is valid
    for (int i = 0; i < 9; i++) {
        if (grid[row][i] == num) {
            //returns false if not valid
            return false;
        }
    }

    //checks to see if column is valid
    for (int i = 0; i < 9; i++) {
        if (grid[i][col] == num) {
            //returns false if not valid
            return false;
        }
    }

    int startRow = (row / 3) * 3;
    int startCol = (col / 3) * 3;

    //checks box to see if it is valid
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (grid[startRow + i][startCol + j] == num) {
                //returns false if not valid
                return false;
            }
        }
    }
    //if valid returns true
    return true;
}

/*
@ name: findEmptyLocation
@ brief: finds an empty location that is not occupied
@ param: &row and &col
@ retval: true or false
*/

bool Sudoku::findEmptyLocation(int& row, int& col) {
    
    //checks to see if place selected is valid
    for (row = 0; row < 9; row++) {
        for (col = 0; col < 9; col++) {
            if (grid[row][col] == 0) {
                //if valid returns true
                return true;
            }
        }
    }
    //if not valid returns false
    return false;
}

/*
@ name: findit
@ brief: solves the sudoku puzzle
@ param: none
@ retval: returns true or false
*/

bool Sudoku::findit() {
    int row, col;

    //first verifies if it is an empty location
    if (!findEmptyLocation(row, col)) {
        return true;
    }

    //begins iteration of numbers 1-9
    for (int num = 1; num <= 9; num++) {
        //checks to see if number is valid
        if (isSafe(row, col, num)) {
            grid[row][col] = num;

            //recursively attempt to solve
            if (findit()) {
                return true;
            }

            grid[row][col] = 0;
        }
    }
    return false;
}

/*
@ name: solve
@ brief: returns value based on if it is possible to solve
@ param: none
@ retval: returns 0 or 1
*/

int Sudoku::solve() {
    //verifies if find it function worked
    if (findit()) {
        return 1;
    }
    return 0;
}

/*
@ name: printGrid
@ brief: prints sudoku grid puzzle
@ param: none
@ retval: none
*/

void Sudoku::printGrid() const {
    for (int i = 0; i < 9; i++) {
        //every 3 rows prints -------
        if (i % 3 == 0 && i != 0) {
            cout << "--------------------" << endl;
        }

        for (int j = 0; j < 9; j++) {
            //every three columns prints |
            if (j % 3 == 0 && j != 0) {
                cout << "|";
            }
            
            //replaces every 0 with * when printed onto screen
            if (grid[i][j] == 0) {
                cout << "* ";
            }
            else {
                //prints digits of sudoku puzzle
                cout << grid[i][j] << " ";
            }
        }
        cout << endl;
    }
}

