#ifndef SUDOKU_H
#define SUDOKU_H

#include <iostream>
#include <cstdlib>
#include <vector>

using namespace std;

class Sudoku {
	public:
		Sudoku(int n);
		int solve();
		void printGrid() const;

	private:
		bool isSafe(int row, int col, int num);
		bool findit();
		void generatePuzzle(int n);
		bool findEmptyLocation(int& row, int& col);

		std::vector<std::vector<int>> grid;
};


#endif
