#include "sudoku.h"
#include <iostream>

using namespace std;

/*
@ name: main
@ brief: uses functions to print and solve a sudoku puzzle
@ param: none
@ retval: none
*/

int main()
{
	int n;
	cout << "Welcome to SudokuSolver!!" << endl;
	cout << "Enter number of squares to prepopulate: ";
	cin >> n;
	//calls constructor
	Sudoku s(n);

	cout << "Initial Sudoku Puzzle:" << endl;
	s.printGrid();

	//if puzzle solved then it will show solution
	if (s.solve()) {
		cout << "Solved!" << endl;
		s.printGrid();
	}

	//otherwise it will declare it is unsolvable
	else {
		cout << "Sorry, unsolvable..." << endl;
	}
	return 0;
}
